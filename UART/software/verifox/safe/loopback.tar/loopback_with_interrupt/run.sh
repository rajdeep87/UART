#!/bin/bash
verifox-fi loopback64.c --verbosity 10
